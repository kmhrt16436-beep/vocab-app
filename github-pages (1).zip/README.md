# 単語学習アプリ — GitHub Pages公開手順

CSS・JavaScriptを含む単体の `index.html` です。外部ライブラリ、ビルド、サーバー設定は不要です。

## 1. リポジトリを作る

1. GitHubにログインし、右上の「＋」→「New repository」を開きます。
2. Repository name に `word-study` などを入力します。
3. 無料アカウントで公開する場合は **Public** を選択します。
4. 「Create repository」を押します。

## 2. ファイルをアップロードする

1. 配布ZIPを展開します。ZIP自体をアップロードするのではありません。
2. リポジトリ画面の「uploading an existing file」または「Add file」→「Upload files」を選びます。
3. 展開した `index.html` と `README.md`、表示できれば `.nojekyll` をアップロードします。
4. 「Commit changes」で保存します。ブランチは `main` を使用します。

`index.html` はリポジトリ直下に置きます。フォルダーごとアップロードして一段深い場所に置かないでください。

```text
word-study/
├── index.html
├── README.md
└── .nojekyll
```

`.nojekyll` はJekyllによる処理を省略するための空ファイルです。隠しファイルとして表示されずアップロードできなくても、このアプリは `index.html` だけで公開できます。

## 3. GitHub Pagesを有効にする

1. リポジトリの **Settings → Pages** を開きます。
2. **Build and deployment → Source** を **Deploy from a branch** にします。
3. **Branch** を **main**、フォルダーを **/ (root)** にします。
4. **Save** を押します。
5. 数分待ってPages画面を更新し、公開URLまたは「Visit site」を開きます。

通常のURLは次の形式です。

```text
https://あなたのユーザー名.github.io/word-study/
```

リポジトリ名を変更した場合はURL末尾も変わります。公開処理の状況は **Actions** の `pages build and deployment` から確認できます。

## 4. Android Chromeで使う

公開URLをChromeで開きます。メニューから「ホーム画面に追加」を選ぶと開きやすくなります。このアプリはPWAではないため、公開URLをオフラインで再度開けることは保証しません。

新しく開いたブラウザでは5枚のサンプルカードが表示されます。作成済みの126項目CSVはアプリの「データ」→「CSVを貼り付け」から追加できます。CSVはこの公開用ZIPには含めていません。

## 以前のカード・進捗を移す

ローカルファイル版とGitHub Pages版は保存場所が異なるため、自動では引き継がれません。

1. 以前のアプリで「データ」→「JSONをエクスポート」を押します。
2. 公開URLのアプリで、そのJSONファイルを選択します。
3. 「JSONから復元する」を押して置き換えます。

学習データは端末・ブラウザのlocalStorageに保存され、GitHubには送信されません。別端末とは自動同期しません。定期的にJSONをバックアップしてください。同じGitHub Pagesドメインにこのアプリを複製すると保存キーが共通のため、データを共有します。

## 更新する

同じリポジトリ直下の `index.html` を更新してコミットすると、GitHub Pagesも自動更新されます。同じ公開URL・ブラウザで利用し保存形式が変わらなければ、学習データはそのまま残ります。

## 表示されない場合

- 404：公開処理の完了を待ち、`main` と `/ (root)` の設定を確認します。
- 404が続く：ファイル名が小文字の `index.html` で、リポジトリ直下にあるか確認します。
- 古い画面：ページを再読み込みします。ブラウザのサイトデータを消すと進捗も消えるため、先にJSONを保存します。
- 画像が出ない：HTTPSの画像URLを使ってください。絵文字のイラストには通信が不要です。

公開リポジトリ内のファイルは誰でも閲覧できます。個人のバックアップJSONをリポジトリに追加する必要はありません。
